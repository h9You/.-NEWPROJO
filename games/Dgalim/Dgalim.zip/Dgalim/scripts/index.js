import {countries} from './countryService.js';
import {createCards} from './domService.js';

createCards();
