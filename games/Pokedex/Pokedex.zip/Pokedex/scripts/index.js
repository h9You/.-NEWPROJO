import { pokemon } from './PokemonService.js';
import { createCards } from './DomService.js';

createCards();